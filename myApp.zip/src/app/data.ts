export class Data {
  temp_machine_1: any;
  temp_machine_2(temp_machine_2: any) {
    throw new Error("Method not implemented.");
  }
}
