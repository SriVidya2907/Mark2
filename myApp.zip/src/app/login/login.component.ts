import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  fname:any[]=[];
  pname:any[]=[];

  check(fname,pname)/*function to check userid & password*/ {
    /*the following code checkes whether the entered userid and password are matching*/
    if (fname!="admin" && pname!="admin") {
      var url = 'http://localhost:4200/homepage';
      window.open(url); /*opens the target page while Id & password matches*/
    }
    else {
      alert("Error Password or Username")/*displays error message*/
    }
  }

}
